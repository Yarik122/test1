import serial
import matplotlib.pyplot as plt

while 1:
    user = input("MODE: ")
    if(user == "1"):
        file = open("testPy.txt",'w')
        ser = serial.Serial("COM4", 9600)
        arDat = 0

        while int(arDat) < 1023:
            arDat = ser.readline().decode("ascii")
            print("POTEN: "+arDat)
            file.write(arDat.rstrip("\n"))
    
        print("----------\nPoten of\n")
        file.close()
        ser.close()
    else:
        file = open("testPy.txt",'r')

        mass=file.read()
        mass = mass.split("\n")
        mass = [int(mass[i]) for i in range(len(mass)-1)]

        plt.plot(mass)
        plt.show()