﻿def basNum(nm):
    print ('nm: '+str(nm))
    s = 2
    while s < nm:
        print ('     s: '+str(s))
        if(nm %s == 0):
            return False 
            break
        
        s+=1

    return True

MS = []
while 1:
    Num = int(input('Введите число: '))
    n = 2
    i = 0
    while Num > 1 and n <= Num:
        if basNum(n) == True:
            if(Num % n == 0):
                #print('NUM: ' + str(Num))
                #print(' ' + str(n), end='')
                MS.insert(i,n)
                i+=1
                Num /= n
                n=2
        n+=1
    i-=1
    print('Итог: ', end='')
    while i >= 0:
        print(' '+str(MS[i]),end='')
        i-=1
    print(' ')